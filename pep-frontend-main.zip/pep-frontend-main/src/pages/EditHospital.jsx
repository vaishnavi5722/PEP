// src/EditHospital.jsx
import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const EditHospital = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { hospital } = location.state;

  const [formData, setFormData] = useState({
    name: hospital.name,
    city: hospital.city,
    rating: hospital.rating,
    image: hospital.image,
    description: hospital.description,
    images: hospital.images.join(", "),
    numberOfDoctors: hospital.numberOfDoctors,
    numberOfDepartments: hospital.numberOfDepartments,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const updatedHospital = {
      ...hospital,
      ...formData,
      images: formData.images.split(",").map((img) => img.trim()),
    };

    const response = await fetch(
      `https://pep-backend.onrender.com/api/v1/hospitals/update?id=${hospital._id}`,
      {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updatedHospital),
      }
    );

    if (response.ok) {
      navigate(`/hospitals/${hospital._id}`, {
        state: { hospital: updatedHospital },
      });
    } else {
      // Handle error
      alert("Failed to update hospital");
    }
  };

  return (
    <div style={styles.container}>
      <h2>Edit Hospital Details</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
        <label>
          Name:
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            style={styles.input}
          />
        </label>
        <label>
          City:
          <input
            type="text"
            name="city"
            value={formData.city}
            onChange={handleChange}
            style={styles.input}
          />
        </label>
        <label>
          Rating:
          <input
            type="number"
            name="rating"
            value={formData.rating}
            onChange={handleChange}
            style={styles.input}
          />
        </label>
        <label>
          Image URL:
          <input
            type="text"
            name="image"
            value={formData.image}
            onChange={handleChange}
            style={styles.input}
          />
        </label>
        <label>
          Description:
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            style={styles.textarea}
          />
        </label>
        <label>
          Additional Images (comma separated):
          <input
            type="text"
            name="images"
            value={formData.images}
            onChange={handleChange}
            style={styles.input}
          />
        </label>
        <label>
          Number of Doctors:
          <input
            type="number"
            name="numberOfDoctors"
            value={formData.numberOfDoctors}
            onChange={handleChange}
            style={styles.input}
          />
        </label>
        <label>
          Number of Departments:
          <input
            type="number"
            name="numberOfDepartments"
            value={formData.numberOfDepartments}
            onChange={handleChange}
            style={styles.input}
          />
        </label>
        <button type="submit" style={styles.button}>
          Save Changes
        </button>
      </form>
    </div>
  );
};

const styles = {
  container: {
    padding: "1rem",
    backgroundColor: "#f9f9f9",
    borderRadius: "8px",
    boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)",
    maxWidth: "800px",
    margin: "2rem auto",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "1rem",
  },
  input: {
    padding: "0.5rem",
    borderRadius: "4px",
    border: "1px solid #ccc",
  },
  textarea: {
    padding: "0.5rem",
    borderRadius: "4px",
    border: "1px solid #ccc",
    resize: "vertical",
  },
  button: {
    padding: "0.5rem 1rem",
    backgroundColor: "#007bff",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  },
};

export default EditHospital;
