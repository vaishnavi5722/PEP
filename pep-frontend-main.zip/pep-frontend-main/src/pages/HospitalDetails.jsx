// src/HospitalDetails.jsx
import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

const HospitalDetails = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { hospital } = location.state;

  const handleEdit = () => {
    navigate(`/hospitals/edit/${hospital._id}`, { state: { hospital } });
  };

  return (
    <div style={styles.container}>
      <h2>{hospital.name}</h2>
      <p>
        <strong>City:</strong> {hospital.city}
      </p>
      <p>
        <strong>Rating:</strong> {hospital.rating}
      </p>
      <img src={hospital.image} alt={hospital.name} style={styles.mainImage} />
      <p>
        <strong>Description:</strong> {hospital.description}
      </p>
      <p>
        <strong>Specialities:</strong> {hospital.speciality.join(", ")}
      </p>
      <p>
        <strong>Number of Doctors:</strong> {hospital.numberOfDoctors}
      </p>
      <p>
        <strong>Number of Departments:</strong> {hospital.numberOfDepartments}
      </p>
      <div style={styles.additionalImagesContainer}>
        {hospital.images.map((img, index) => (
          <img
            key={index}
            src={img}
            alt={`${hospital.name} ${index}`}
            style={styles.additionalImage}
          />
        ))}
      </div>
      <button onClick={handleEdit} style={styles.button}>
        Edit Hospital
      </button>
    </div>
  );
};

const styles = {
  container: {
    padding: "1rem",
    backgroundColor: "#f9f9f9",
    borderRadius: "8px",
    boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)",
    maxWidth: "800px",
    margin: "2rem auto",
  },
  mainImage: {
    width: "100%",
    maxHeight: "400px",
    objectFit: "cover",
    borderRadius: "8px",
  },
  additionalImagesContainer: {
    display: "flex",
    flexWrap: "wrap",
    gap: "1rem",
    marginTop: "1rem",
  },
  additionalImage: {
    width: "calc(33.333% - 1rem)",
    maxHeight: "200px",
    objectFit: "cover",
    borderRadius: "8px",
  },
  button: {
    padding: "0.5rem 1rem",
    backgroundColor: "#007bff",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
    marginTop: "1rem",
  },
};

export default HospitalDetails;
