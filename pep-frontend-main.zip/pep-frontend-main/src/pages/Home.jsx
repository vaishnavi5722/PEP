// src/Home.jsx
import React from "react";
import HospitalForm from "../components/HospitalForm";

const Home = () => {
  const handleHospitalSubmit = (hospitalData) => {
    console.log("New hospital added:", hospitalData);
    // You can replace this console.log with the actual API call to submit the form data
  };

  return (
    <div>
      <h2>Create Hospital</h2>
      <HospitalForm onSubmit={handleHospitalSubmit} />
    </div>
  );
};

export default Home;
