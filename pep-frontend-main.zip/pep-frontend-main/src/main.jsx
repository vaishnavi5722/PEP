// src/main.jsx
import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import "./index.css";
import "./styles.css";
import Home from "./pages/Home";
import About from "./pages/About";
import HospitalListByCity from "./components/HospitalListByCity";
import HospitalDetails from "./pages/HospitalDetails";

import EditHospital from "./pages/EditHospital";

ReactDOM.render(
  <Router>
    <nav>
      <ul>
        <li>
          <Link to="/">Create Hospital</Link>
        </li>
        <li>
          <Link to="/hospitals-by-city">Hospitals by City</Link>
        </li>
      </ul>
    </nav>
    <div className="container">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/hospitals-by-city" element={<HospitalListByCity />} />
        <Route path="/hospitals/:id" element={<HospitalDetails />} />
        <Route path="/hospitals/edit/:id" element={<EditHospital />} />
      </Routes>
    </div>
  </Router>,
  document.getElementById("root")
);
