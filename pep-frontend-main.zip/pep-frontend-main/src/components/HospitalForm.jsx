// src/HospitalForm.jsx
import React, { useState } from "react";

const HospitalForm = () => {
  const [name, setName] = useState("");
  const [city, setCity] = useState("");
  const [image, setImage] = useState("");
  const [specialities, setSpecialities] = useState([]);
  const [rating, setRating] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const specialitiesOptions = [
    "Cardiology",
    "Neurology",
    "Orthopedics",
    "Pediatrics",
    "Oncology",
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess("");

    const hospitalData = {
      name,
      city,
      image,
      speciality: specialities,
      rating: parseFloat(rating),
    };

    try {
      const response = await fetch(
        "https://pep-backend.onrender.com/api/v1/hospitals/create",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(hospitalData),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to submit hospital data");
      }

      const result = await response.json();
      setSuccess("Hospital added successfully!");
      // Reset form
      setName("");
      setCity("");
      setImage("");
      setSpecialities([]);
      setRating("");
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSpecialityChange = (e) => {
    const value = Array.from(
      e.target.selectedOptions,
      (option) => option.value
    );
    setSpecialities(value);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>
          Name:
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </label>
      </div>
      <div>
        <label>
          City:
          <input
            type="text"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            required
          />
        </label>
      </div>
      <div>
        <label>
          Image URL:
          <input
            type="text"
            value={image}
            onChange={(e) => setImage(e.target.value)}
            required
          />
        </label>
      </div>
      <div>
        <label>
          Specialities:
          <select
            multiple
            value={specialities}
            onChange={handleSpecialityChange}
            required
          >
            {specialitiesOptions.map((speciality) => (
              <option key={speciality} value={speciality}>
                {speciality}
              </option>
            ))}
          </select>
        </label>
      </div>
      <div>
        <label>
          Rating:
          <input
            type="number"
            step="0.1"
            min="0"
            max="5"
            value={rating}
            onChange={(e) => setRating(e.target.value)}
            required
          />
        </label>
      </div>
      <button type="submit" disabled={loading}>
        {loading ? "Submitting..." : "Add Hospital"}
      </button>
      {error && <div style={{ color: "red" }}>{error}</div>}
      {success && <div style={{ color: "green" }}>{success}</div>}
    </form>
  );
};

export default HospitalForm;
