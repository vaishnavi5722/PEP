// src/HospitalListByCity.jsx
import React, { useState, useEffect } from "react";
import HospitalListItem from "./HospitalListItem";

const HospitalListByCity = () => {
  const [city, setCity] = useState("");
  const [hospitals, setHospitals] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [noResults, setNoResults] = useState(false);

  useEffect(() => {
    // Fetch all hospitals on initial render
    const fetchHospitals = async () => {
      setLoading(true);
      setError("");
      setNoResults(false);

      try {
        const response = await fetch(
          "https://pep-backend.onrender.com/api/v1/hospitals"
        );
        if (response.status === 404) {
          setNoResults(true);
          return;
        }
        if (!response.ok) {
          throw new Error("Failed to fetch hospitals");
        }
        const data = await response.json();
        setHospitals(data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchHospitals();
  }, []);

  const handleDelete = (id) => {
    setHospitals(hospitals.filter((hospital) => hospital._id !== id));
  };

  const handleSearch = async () => {
    if (!city) {
      setError("Please enter a city");
      return;
    }
    setLoading(true);
    setError("");
    setNoResults(false);

    try {
      const response = await fetch(
        `https://pep-backend.onrender.com/api/v1/hospitals?city=${city}`
      );
      if (response.status === 404) {
        setNoResults(true);
        setHospitals([]);
        return;
      }
      if (!response.ok) {
        throw new Error("Failed to fetch hospitals");
      }
      const data = await response.json();
      if (data.length === 0) {
        setNoResults(true);
      } else {
        setHospitals(data);
      }
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2>Find Hospitals by City</h2>
      <div style={{ marginBottom: "1rem", textAlign: "center" }}>
        <input
          type="text"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          placeholder="Enter city"
          style={{
            padding: "0.5rem",
            width: "80%",
            borderRadius: "5px",
            border: "1px solid #ddd",
          }}
        />
        <button
          onClick={handleSearch}
          disabled={loading}
          style={{
            padding: "0.5rem 1rem",
            marginLeft: "0.5rem",
            backgroundColor: "#007bff",
            color: "white",
            border: "none",
            borderRadius: "5px",
          }}
        >
          {loading ? "Searching..." : "Search"}
        </button>
      </div>
      {error && (
        <div style={{ color: "#dc3545", textAlign: "center" }}>{error}</div>
      )}
      {noResults && (
        <div
          style={{ textAlign: "center", fontSize: "1rem", color: "#dc3545" }}
        >
          No Result Found
        </div>
      )}
      {hospitals.length > 0 && !noResults && (
        <ul style={{ listStyleType: "none", padding: "0" }}>
          {hospitals.map((hospital) => (
            <HospitalListItem
              key={hospital._id}
              hospital={hospital}
              onDelete={handleDelete}
            />
          ))}
        </ul>
      )}
    </div>
  );
};

export default HospitalListByCity;
