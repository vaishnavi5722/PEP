// src/HospitalListItem.jsx
import React from "react";
import { useNavigate } from "react-router-dom";

const HospitalListItem = ({ hospital, onDelete }) => {
  const navigate = useNavigate();

  const handleViewDetails = () => {
    navigate(`/hospitals/${hospital._id}`, { state: { hospital } });
  };

  const handleDelete = async () => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this hospital?"
    );
    if (confirmDelete) {
      const response = await fetch(
        `https://pep-backend.onrender.com/api/v1/hospitals/delete?id=${hospital._id}`,
        {
          method: "DELETE",
        }
      );

      if (response.ok) {
        onDelete(hospital._id);
      } else {
        alert("Failed to delete hospital");
      }
    }
  };

  return (
    <div style={styles.container}>
      <img src={hospital.image} alt={hospital.name} style={styles.image} />
      <div style={styles.details}>
        <h3>{hospital.name}</h3>
        <p>{hospital.city}</p>
        <p>{hospital.speciality.join(", ")}</p>
        <p>Rating: {hospital.rating}</p>
        <button onClick={handleViewDetails} style={styles.button}>
          View Details
        </button>
        <button
          onClick={handleDelete}
          style={{ ...styles.button, backgroundColor: "red" }}
        >
          Delete
        </button>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "1rem",
    backgroundColor: "#f9f9f9",
    borderRadius: "8px",
    boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)",
    marginBottom: "1rem",
  },
  image: {
    width: "150px",
    height: "100px",
    objectFit: "cover",
    borderRadius: "8px",
  },
  details: {
    flex: 1,
    marginLeft: "1rem",
  },
  button: {
    padding: "0.5rem 1rem",
    backgroundColor: "#007bff",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
    marginLeft: "0.5rem",
  },
};

export default HospitalListItem;
