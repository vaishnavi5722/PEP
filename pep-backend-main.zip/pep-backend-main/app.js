import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import hospitalRouter from './routes/hospitalRouter.js';

const app = express();
const port = 3000;

// Middleware setup
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Use the hospital router
app.use('/api/v1/hospitals', hospitalRouter);

// Root route
app.get('/', (req, res) => {
  res.send('Hello, World!');
});


export default app;