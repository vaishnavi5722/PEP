import mongoose from 'mongoose';

const hospitalSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  city: {
    type: String,
    required: true,
  },
  image: {
    type: String,
    required: true,  // Ensure it's a valid URL in a more detailed implementation
  },
  speciality: {
    type: [String],
    required: true,
  },
  rating: {
    type: Number,
    required: true,
  },
  description: {
    type: String,
  },
  images: {
    type: [String],  // Ensure each entry is a valid URL in a more detailed implementation
  },
  numberOfDoctors: {
    type: Number,
  },
  numberOfDepartments: {
    type: Number,

  },
});

const Hospital = mongoose.model('Hospital', hospitalSchema);

export default Hospital;