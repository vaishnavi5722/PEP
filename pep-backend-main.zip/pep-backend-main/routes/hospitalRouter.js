import express from 'express';
import { createHospital } from '../controller/hospital/create.js';
import { getHospitalsByCity } from '../controller/hospital/getByCity.js';
import { deleteHospital } from '../controller/hospital/delete.js';
import { updateHospital } from '../controller/hospital/update.js';
import { addHospitalDetails } from '../controller/hospital/addDetails.js';
import { fetch } from '../controller/hospital/fetch.js';

const router = express.Router();


// Route to create a hospital
router.post('/create', createHospital);

// Route to fetch hospital by _id

router.get('/:id', fetch);

// Route to get hospitals by city
router.get('/', getHospitalsByCity);

// Route to delete a hospital
router.delete('/delete', deleteHospital);

// Route to update a hospital
router.put('/update', updateHospital);

// Route to add or update additional hospital details
router.post('/details', addHospitalDetails);

export default router;