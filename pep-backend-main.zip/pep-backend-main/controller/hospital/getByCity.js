import Hospital from '../../models/Hospital.js';

export const getHospitalsByCity = async (req, res) => {
  const { city } = req.query;

  try {
    let hospitals;

    if (city) {
      hospitals = await Hospital.find({ city: { $regex: new RegExp(city, "i") } });
    } else {
      hospitals = await Hospital.find({});
    }

    if (hospitals.length === 0) {
      return res.status(404).json({ message: 'No hospitals found.' });
    }

    res.status(200).json(hospitals);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching hospitals', error: error.message });
  }
};