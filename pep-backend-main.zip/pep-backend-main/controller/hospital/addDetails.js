import Hospital from '../../models/Hospital.js';

export const addHospitalDetails = async (req, res) => {
  const { id } = req.query;
  const updates = req.body;

  if (!id) {
    return res.status(400).json({ message: 'ID is required.' });
  }

  try {
    const hospital = await Hospital.findById(id);

    if (!hospital) {
      return res.status(404).json({ message: 'Hospital not found.' });
    }

    // Merge updates with existing hospital details
    const updatedHospital = await Hospital.findByIdAndUpdate(
      id,
      { $set: updates },
      { new: true, runValidators: true }
    );

    res.status(200).json({
      message: 'Hospital details updated successfully',
      hospital: updatedHospital,
    });
  } catch (error) {
    res.status(500).json({ message: 'Error updating hospital details', error: error.message });
  }
};