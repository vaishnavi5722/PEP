import Hospital from '../../models/Hospital.js';

export const deleteHospital = async (req, res) => {
  const { id } = req.query;

  if (!id) {
    return res.status(400).json({ message: 'ID is required.' });
  }

  try {
    const hospital = await Hospital.findByIdAndDelete(id);

    if (!hospital) {
      return res.status(404).json({ message: 'Hospital not found.' });
    }

    res.status(200).json({ message: 'Hospital deleted successfully.' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting hospital', error: error.message });
  }
};