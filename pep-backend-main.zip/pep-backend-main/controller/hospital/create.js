import Hospital from '../../models/Hospital.js';

export const createHospital = async (req, res) => {
  const { name, city, image, speciality, rating, description, images, numberOfDoctors, numberOfDepartments } = req.body;

  if (!name || !city || !image || !speciality || !rating) {
    return res.status(400).json({ message: 'Name, city, image, speciality, and rating are required.' });
  }


  try {
    const newHospital = new Hospital({
      name,
      city,
      image,
      speciality,
      rating,
      description,
      images,
      numberOfDoctors,
      numberOfDepartments
    });
    await newHospital.save();

    res.status(201).json({
      message: 'Hospital created successfully',
      hospital: newHospital,
    });
  } catch (error) {
    res.status(500).json({ message: 'Error creating hospital', error: error.message });
  }
};