import Hospital from '../../models/Hospital.js';

export const updateHospital = async (req, res) => {
  const { id } = req.query;
  const updates = req.body;

  if (!id) {
    return res.status(400).json({ message: 'ID is required.' });
  }

  try {
    const hospital = await Hospital.findByIdAndUpdate(id, updates, { new: true, runValidators: true });

    if (!hospital) {
      return res.status(404).json({ message: 'Hospital not found.' });
    }

    res.status(200).json({
      message: 'Hospital updated successfully',
      hospital
    });
  } catch (error) {
    res.status(500).json({ message: 'Error updating hospital', error: error.message });
  }
};