import Hospital from '../../models/Hospital.js';

export const fetch = async (req, res) => {
  const { id } = req.params;

  if (!id) {
    return res.status(400).json({ message: 'City is required.' });
  }

  try {
    let hospitals =  await Hospital.find({_id: id});



    if (hospitals.length === 0) {
      return res.status(404).json({ message: 'No hospitals found.' });
    }

    

    res.status(200).json(hospitals[0]);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching hospitals', error: error.message });
  }
};